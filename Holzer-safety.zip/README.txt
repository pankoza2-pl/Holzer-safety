#################################
#  _    _       _               #
# | |  | |     | |              #
# | |__| | ___ | |_______ _ __  #
# |  __  |/ _ \| |_  / _ \ '__| #
# | |  | | (_) | |/ /  __/ |    #
# |_|  |_|\___/|_/___\___|_|    #
#                               # (safety version)
#################################

If you don't know what is the Holzer.exe file do, then
do not run, and delete the file. This program is a malware.
This will destroy your system.

WARNING:
If you have something that hurts your eyes
such as epilepsy, then DO NOT RUN THIS MALWARE!

Creator: Dominik111 (safety version by pankoza)
Version: 1.2
Written in: C++
MBR code: SleepMod

This little trojan will create some GDI effects, open programs,
random cursor clicks, keyboard input, moving the program window,
renaming the window titles, some ByteBeat and at the end, it calls
2 undocumented features: RtlAdjustPrivileges, NtRaiseHardError. (safety version only has GDI and ByteBeat)
It also uses the Xorshift32 function. And as always, a little
classic MBR. I have zero knowledge in assembly so the MBR message
code is from: SleepMod

Before the destruction begins, there's 2 warning, so
nothing will happen when running by an accident.
User Account Control will also appear in Windows Vista and newer.
Without admin privileges, it won't be able to overwrite the MBR. So
be sure to run as admin (it will run as admin by default)! On Windows XP
you can just run it, it will can overwrite in anyway.

Only try this in a Virtual Machine.

There's a bug that it will stop because the ByteBeat code
is coded wrongly, I am trying to fix that as soon as possible
but I'm not a big C++ brain.

I made this trojan only for educational purposes!

DISCLAIMER:
I am not responsible for any damage
made to your computer.

Note: If the effects are slow, then try it in Windows XP.